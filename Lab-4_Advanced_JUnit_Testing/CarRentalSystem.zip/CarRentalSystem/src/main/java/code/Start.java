package code;




public class Start {
	public static void main(String[] args)
	{
		RentSystem rentSystem =new RentSystem();
		rentSystem.run();
	}

}
